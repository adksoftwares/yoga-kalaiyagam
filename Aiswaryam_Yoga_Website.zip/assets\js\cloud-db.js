/**
 * ஸ்ரீ ஐஸ்வர்யம் யோகா கலையகம் - கிளவுட் டேட்டாபேஸ் இணைப்பு
 * Aiswaryam Yoga Kalaiyagam - Cloud Sync & Local-First Database Engine
 * Supports Supabase / Firebase / REST API with offline resilience
 */

const CLOUD_CONFIG_KEY = 'aiswaryam_cloud_config';

// Default Master Data (No fake events; real events published by admin)
const DEFAULT_EVENTS = [];

const DEFAULT_GALLERY = [];

class YogaCloudDB {
  constructor() {
    this.config = this.loadConfig();
  }

  loadConfig() {
    try {
      const cfg = localStorage.getItem(CLOUD_CONFIG_KEY);
      const publicConfig = window.YOGA_SUPABASE_CONFIG || {};
      const defaults = {
        provider: publicConfig.url && publicConfig.anonKey ? 'supabase' : 'local',
        supabaseUrl: publicConfig.url || '',
        supabaseKey: publicConfig.anonKey || '',
        syncEnabled: Boolean(publicConfig.url && publicConfig.anonKey)
      };
      if (!cfg) return defaults;
      const saved = JSON.parse(cfg);
      return {
        ...defaults,
        ...saved,
        supabaseUrl: publicConfig.url || saved.supabaseUrl || '',
        supabaseKey: publicConfig.anonKey || saved.supabaseKey || '',
        provider: publicConfig.url && publicConfig.anonKey ? 'supabase' : (saved.provider || 'local'),
        syncEnabled: publicConfig.url && publicConfig.anonKey ? true : Boolean(saved.syncEnabled)
      };
    } catch (e) {
      const publicConfig = window.YOGA_SUPABASE_CONFIG || {};
      return {
        provider: publicConfig.url && publicConfig.anonKey ? 'supabase' : 'local',
        supabaseUrl: publicConfig.url || '',
        supabaseKey: publicConfig.anonKey || '',
        syncEnabled: Boolean(publicConfig.url && publicConfig.anonKey)
      };
    }
  }

  saveConfig(newConfig) {
    this.config = { ...this.config, ...newConfig };
    localStorage.setItem(CLOUD_CONFIG_KEY, JSON.stringify(this.config));
  }

  getAccessToken() {
    try {
      return sessionStorage.getItem('aiswaryam_admin_access_token') ||
        sessionStorage.getItem('aiswaryam_student_access_token') ||
        this.config.supabaseKey;
    } catch {
      return this.config.supabaseKey;
    }
  }

  getAuthHeaders(extra = {}) {
    return {
      apikey: this.config.supabaseKey,
      Authorization: `Bearer ${this.getAccessToken()}`,
      ...extra
    };
  }

  async ensureOk(response, action) {
    if (!response.ok) {
      const detail = await response.text().catch(() => '');
      throw new Error(`${action} failed (${response.status}): ${detail.slice(0, 180)}`);
    }
    return response;
  }

  isCloudConfigured() {
    return Boolean(this.config.syncEnabled && this.config.provider === 'supabase' &&
      this.config.supabaseUrl && this.config.supabaseKey);
  }

  async fetchAdminRecords(table) {
    const allowedTables = new Set(['memberships', 'bookings']);
    if (!allowedTables.has(table)) throw new Error('Unsupported table');
    if (!this.isCloudConfigured()) return [];
    const response = await fetch(`${this.config.supabaseUrl}/rest/v1/${table}?select=*&order=created_at.desc`, {
      headers: this.getAuthHeaders()
    });
    await this.ensureOk(response, `Load ${table}`);
    const rows = await response.json();
    return Array.isArray(rows) ? rows : [];
  }

  async fetchNotice() {
    if (!this.isCloudConfigured()) return null;
    const response = await fetch(`${this.config.supabaseUrl}/rest/v1/site_settings?select=value&id=eq.top_notice&limit=1`, {
      headers: this.getAuthHeaders()
    });
    await this.ensureOk(response, 'Load announcement');
    const rows = await response.json();
    return Array.isArray(rows) && rows.length ? String(rows[0].value || '') : '';
  }

  async saveNotice(value) {
    if (!this.isCloudConfigured()) throw new Error('Supabase is not configured.');
    const response = await fetch(`${this.config.supabaseUrl}/rest/v1/site_settings?on_conflict=id`, {
      method: 'POST',
      headers: this.getAuthHeaders({
        'Content-Type': 'application/json',
        Prefer: 'resolution=merge-duplicates,return=minimal'
      }),
      body: JSON.stringify({ id: 'top_notice', value: String(value || '').slice(0, 500) })
    });
    await this.ensureOk(response, 'Save announcement');
  }

  async submitMembership(record) {
    if (!this.isCloudConfigured()) return { persisted: false };
    const payload = {
      reg_id: record.regId,
      full_name: record.fullName,
      phone: record.phone,
      email: record.email || null,
      age: /^\\d+$/.test(String(record.age)) ? Number(record.age) : null,
      gender: record.gender || null,
      batch: record.batch,
      branch: record.branch || null,
      selected_plan: record.selectedPlan,
      address: record.address || null
    };
    const response = await fetch(`${this.config.supabaseUrl}/rest/v1/memberships`, {
      method: 'POST',
      headers: {
        apikey: this.config.supabaseKey,
        Authorization: `Bearer ${this.config.supabaseKey}`,
        'Content-Type': 'application/json',
        Prefer: 'return=minimal'
      },
      body: JSON.stringify(payload)
    });
    await this.ensureOk(response, 'Submit membership request');
    return { persisted: true };
  }

  async submitBooking(record) {
    if (!this.isCloudConfigured()) return { persisted: false };
    const payload = {
      booking_id: record.bookId,
      full_name: record.name,
      phone: record.phone,
      session_type: record.sessionType,
      booking_date: record.date,
      slot: record.slot,
      branch: record.branch,
      notes: record.notes || null
    };
    const response = await fetch(`${this.config.supabaseUrl}/rest/v1/bookings`, {
      method: 'POST',
      headers: {
        apikey: this.config.supabaseKey,
        Authorization: `Bearer ${this.config.supabaseKey}`,
        'Content-Type': 'application/json',
        Prefer: 'return=minimal'
      },
      body: JSON.stringify(payload)
    });
    await this.ensureOk(response, 'Submit booking request');
    return { persisted: true };
  }

  // 1. EVENTS MANAGEMENT (Cloud + Local First)
  async fetchEvents() {
    if (this.config.syncEnabled && this.config.provider === 'supabase' && this.config.supabaseUrl) {
      try {
        const res = await fetch(`${this.config.supabaseUrl}/rest/v1/events?select=*&order=date.desc`, {
          headers: {
            'apikey': this.config.supabaseKey,
            'Authorization': `Bearer ${this.getAccessToken()}`
          }
        });
        if (res.ok) {
          const cloudData = await res.json();
          if (Array.isArray(cloudData)) {
            localStorage.setItem('aiswaryam_events', JSON.stringify(cloudData));
            return cloudData;
          }
        }
      } catch (err) {
        console.warn('[CloudDB] Fallback to local cache for events:', err);
      }
    }

    // LocalStorage fallback with automatic purge of old fake mock events
    const local = localStorage.getItem('aiswaryam_events');
    if (!local) return DEFAULT_EVENTS;
    try {
      const parsed = JSON.parse(local);
      // Purge fake mock events (e.g. 2026-06-21, 2026-07-15, 2026-08-10, or dummy IDs 1, 2, 3)
      const sanitized = Array.isArray(parsed) ? parsed.filter(ev => {
        const title = (ev.titleTa || ev.title || '').toLowerCase();
        const date = ev.date || '';
        const isMock = date === '2026-06-21' || date === '2026-07-15' || date === '2026-08-10' ||
                       title.includes('கல்லடி கடற்கரை சூரிய நமஸ்கார') ||
                       title.includes('international yoga day celebration') ||
                       (ev.id <= 3 && title.includes('சர்வதேச யோகா தினப் பெருவிழா'));
        return !isMock;
      }) : [];
      if (sanitized.length !== parsed.length) {
        localStorage.setItem('aiswaryam_events', JSON.stringify(sanitized));
      }
      return sanitized;
    } catch (e) {
      return DEFAULT_EVENTS;
    }
  }

  async saveEvent(eventObj) {
    if (this.config.syncEnabled && this.config.provider === 'supabase' && this.config.supabaseUrl) {
      const response = await fetch(`${this.config.supabaseUrl}/rest/v1/events`, {
        method: 'POST',
        headers: this.getAuthHeaders({ 'Content-Type': 'application/json', Prefer: 'return=minimal' }),
        body: JSON.stringify(eventObj)
      });
      await this.ensureOk(response, 'Save event');
      return this.fetchEvents();
    }

    const current = await this.fetchEvents();
    current.unshift(eventObj);
    localStorage.setItem('aiswaryam_events', JSON.stringify(current));
    return current;
  }

  async deleteEvent(id) {
    if (this.config.syncEnabled && this.config.provider === 'supabase' && this.config.supabaseUrl) {
      const response = await fetch(`${this.config.supabaseUrl}/rest/v1/events?id=eq.${encodeURIComponent(id)}`, {
        method: 'DELETE',
        headers: this.getAuthHeaders()
      });
      await this.ensureOk(response, 'Delete event');
      return this.fetchEvents();
    }
    const current = (await this.fetchEvents()).filter(event => event.id !== id);
    localStorage.setItem('aiswaryam_events', JSON.stringify(current));
    return current;
  }

  // 2. GALLERY MANAGEMENT (Cloud + Local First)
  async fetchGallery() {
    if (this.config.syncEnabled && this.config.provider === 'supabase' && this.config.supabaseUrl) {
      try {
        const res = await fetch(`${this.config.supabaseUrl}/rest/v1/gallery?select=*&order=id.desc`, {
          headers: {
            'apikey': this.config.supabaseKey,
            'Authorization': `Bearer ${this.getAccessToken()}`
          }
        });
        if (res.ok) {
          const cloudData = await res.json();
          if (Array.isArray(cloudData)) {
            localStorage.setItem('aiswaryam_gallery', JSON.stringify(cloudData));
            return cloudData;
          }
        }
      } catch (err) {
        console.warn('[CloudDB] Fallback to local gallery:', err);
      }
    }

    const local = localStorage.getItem('aiswaryam_gallery');
    if (!local) return DEFAULT_GALLERY;
    try {
      const parsed = JSON.parse(local);
      const isLegacyMock = Array.isArray(parsed) && parsed.some(item => 
        (item.img && item.img.includes('event') && item.img.endsWith('.svg')) ||
        (item.title && (item.title.includes('பிரதான அரங்கம்') || item.title.includes('பிரதான பதாகை')))
      );
      if (isLegacyMock) {
        localStorage.removeItem('aiswaryam_gallery');
        return [];
      }
      return Array.isArray(parsed) ? parsed : [];
    } catch (e) {
      return DEFAULT_GALLERY;
    }
  }

  async saveGalleryItem(photoObj) {
    if (this.config.syncEnabled && this.config.provider === 'supabase' && this.config.supabaseUrl) {
      const response = await fetch(`${this.config.supabaseUrl}/rest/v1/gallery`, {
        method: 'POST',
        headers: this.getAuthHeaders({ 'Content-Type': 'application/json', Prefer: 'return=minimal' }),
        body: JSON.stringify(photoObj)
      });
      await this.ensureOk(response, 'Save gallery item');
      return this.fetchGallery();
    }
    const current = await this.fetchGallery();
    current.unshift(photoObj);
    localStorage.setItem('aiswaryam_gallery', JSON.stringify(current));
    return current;
  }

  async deleteGalleryItem(id) {
    if (this.config.syncEnabled && this.config.provider === 'supabase' && this.config.supabaseUrl) {
      const response = await fetch(`${this.config.supabaseUrl}/rest/v1/gallery?id=eq.${encodeURIComponent(id)}`, {
        method: 'DELETE',
        headers: this.getAuthHeaders()
      });
      await this.ensureOk(response, 'Delete gallery item');
      return this.fetchGallery();
    }
    const current = (await this.fetchGallery()).filter(item => item.id !== id);
    localStorage.setItem('aiswaryam_gallery', JSON.stringify(current));
    return current;
  }

  // 3. Export a backup from the central database when configured.
  async exportFullBackup() {
    let backup;
    if (this.isCloudConfigured()) {
      const [events, gallery, memberships, bookings, notice] = await Promise.all([
        this.fetchEvents(),
        this.fetchGallery(),
        this.fetchAdminRecords('memberships'),
        this.fetchAdminRecords('bookings'),
        this.fetchNotice()
      ]);
      backup = {
        exportDate: new Date().toISOString(),
        centre: 'Yoga Studio Batticaloa',
        source: 'supabase',
        events,
        gallery,
        memberships,
        bookings,
        site_settings: notice ? [{ id: 'top_notice', value: notice }] : []
      };
    } else {
      backup = {
        exportDate: new Date().toISOString(),
        centre: 'Yoga Studio Batticaloa',
        source: 'local-cache',
        events: JSON.parse(localStorage.getItem('aiswaryam_events') || '[]'),
        gallery: JSON.parse(localStorage.getItem('aiswaryam_gallery') || '[]'),
        memberships: [],
        bookings: [],
        site_settings: []
      };
    }

    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `YogaStudio_Batticaloa_Backup_${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  // 4. Merge a backup into Supabase using admin-only RLS; never destructively replace tables.
  async importFullBackup(jsonContent) {
    try {
      const data = JSON.parse(jsonContent);
      if (!data || typeof data !== 'object' || Array.isArray(data)) return false;

      if (this.isCloudConfigured()) {
        const tables = [
          ['events', data.events, 'id'],
          ['gallery', data.gallery, 'id'],
          ['memberships', data.memberships, 'reg_id'],
          ['bookings', data.bookings, 'booking_id'],
          ['site_settings', data.site_settings || (data.notice ? [{ id: 'top_notice', value: data.notice }] : []), 'id']
        ];
        for (const [table, rows, conflictKey] of tables) {
          if (!Array.isArray(rows) || rows.length === 0) continue;
          const response = await fetch(
            `${this.config.supabaseUrl}/rest/v1/${table}?on_conflict=${encodeURIComponent(conflictKey)}`,
            {
              method: 'POST',
              headers: this.getAuthHeaders({
                'Content-Type': 'application/json',
                Prefer: 'resolution=merge-duplicates,return=minimal'
              }),
              body: JSON.stringify(rows)
            }
          );
          await this.ensureOk(response, `Restore ${table}`);
        }
        return true;
      }

      // Local-only import is retained for older offline caches.
      if (Array.isArray(data.events)) localStorage.setItem('aiswaryam_events', JSON.stringify(data.events));
      if (Array.isArray(data.gallery)) localStorage.setItem('aiswaryam_gallery', JSON.stringify(data.gallery));
      if (typeof data.notice === 'string') localStorage.setItem('aiswaryam_top_notice', data.notice);
      return true;
    } catch (error) {
      console.error('[CloudDB] Backup import failed:', error);
      return false;
    }
  }
}

// Global Singleton Instance
window.cloudDB = new YogaCloudDB();
